// Copyright 2015 Square, Inc.
#import <Foundation/Foundation.h>


@interface CocoaPodsDummy : NSObject
@end


@implementation CocoaPodsDummy
@end
